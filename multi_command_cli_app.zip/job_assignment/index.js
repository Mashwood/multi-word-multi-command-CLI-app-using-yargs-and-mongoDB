const mongoose = require('mongoose');
//Connecting to MongoDB localhost server
mongoose.connect('mongodb://localhost:27017/storedb');
var db = mongoose.connection;
//Importing Schema model
const Store = require('./models/store');
//Add key
const addKey = (keys) => {
	console.info(keys)
	Store.create(keys).then(keys => {
	  console.info(keys)
      console.info('New key added');
      db.close();
	});
}
//Find key
const findKey = (key_name) => {
	// Making search case insensitive
	const search = new RegExp(key_name, 'i');
	Store.find({$or: [{key: search}, {key: search}]})
	 .then(values => {
		console.info(values);
		console.info(`${values.length} matches`);
		db.close();
	 });
}
//Remove key
const removeKey = (key) => {
	Store.remove({key})
	 .then(key => {
		 console.info('Key removed');
		 db.close();
	})
}
//List all keys
const listKey = () => {
	Store.find()
	 .then(keys => {
	 	console.info(keys);
	 	console.info(`${keys.length} keys`);
	 	db.close();
	 });
}
//Exporing methods
module.exports = {
	addKey,
	findKey,
	removeKey,
	listKey
}