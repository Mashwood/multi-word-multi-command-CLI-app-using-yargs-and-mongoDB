#!/usr/bin/env node
//Importing all methods
const {
 addKey,
 findKey,
 removeKey,
 listKey
} = require('./index');
const arg = require('yargs').argv
//Conditional if statement for parsing the command
    if (arg._[1] === "add"){
    	const argv = require('yargs') 
      //Command for adding key and value
      .command('now add <key> <value>', 'upload a file', (yargs) => {}, (argv) => {
        addKey({ key: argv.key, value: argv.value });
    })
    .argv;
    }else if (arg._[1] === "get"){
    	const argv = require('yargs') 
      //Command for finding key
      .command('now get <key_name>', 'upload a file', (yargs) => {}, (argv) => {
        findKey(argv.key_name);
    })
    .argv;
    }else if (arg._[1] === "remove"){
    	const argv = require('yargs') 
      //Command for removing key
      .command('now remove <key_name>', 'upload a file', (yargs) => {}, (argv) => {
        removeKey(argv.key_name);
    })
    .argv;
    }else if (arg._[1] === "list"){
    	const argv = require('yargs') 
      ////Command for listing all keys and values
      .command('now list', 'upload a file', (yargs) => {}, (argv) => {
        listKey();
    })
    .argv;
    }else {
      //In case the user gives a wrong command
      console.info("Please check your command")
    }