const mongoose = require('mongoose');
//Defining Schema for MongoDB database
const storeSchema = mongoose.Schema({
	key: { type: String },
	value: { type: String }
});
//Exporting Schema model
module.exports = mongoose.model('Store', storeSchema);
